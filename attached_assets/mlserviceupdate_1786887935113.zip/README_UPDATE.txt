GeneClassifier ml-service update — real data + HistGradientBoosting
=====================================================================

WHAT'S IN THIS ZIP
- model.py               -> replaces ml-service/model.py entirely
- main.py                -> replaces ml-service/main.py entirely
- training_data_real.csv -> new file, add to ml-service/ folder

HOW TO APPLY ON REPLIT
1. Open your ml-service folder in Replit.
2. Delete model.pkl and model_registry.json if they exist (old synthetic
   model + registry — the service regenerates both automatically).
3. Upload/replace model.py and main.py with the versions in this zip.
4. Upload training_data_real.csv into the same ml-service folder.
5. Restart the service. On startup it will automatically train on the real
   data (takes ~10-15 seconds) and save a fresh model.pkl + model_registry.json.

WHAT CHANGED
- Training data: was synthetic/fabricated (np.random with hand-picked offsets),
  now real TCGA PanCancer Atlas mRNA expression data (3,330 real patient
  samples across BRCA, LUAD, COADREAD, GBM, PRAD from cBioPortal).
- Model: RandomForestClassifier -> HistGradientBoostingClassifier
  (86.5% cross-validated accuracy on real data, vs the old 76.8% RF baseline
  on the same real data, and vs a meaningless 92.4% on fake data before).
- Explainability: feature_importances_ (RF-only) -> permutation_importance
  (works for any model, same downstream "explain" logic otherwise).
- Registry: keeps v1 (synthetic, marked superseded) and v2 (real, active)
  so there's a visible, honest history of the change.

NOTE ON LABELS
The "COAD" subtype label is really COADREAD (colon + rectal combined) in the
source TCGA cohort — the code now labels it "COAD (Colorectal)" instead of
"COAD (Colon)" to be accurate. Worth mentioning explicitly in your FYP writeup.
